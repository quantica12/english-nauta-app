import React, { useEffect, useMemo, useRef, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, BookOpen, CalendarCheck, TrendingUp, Search, Plus, Pencil, Trash2, Check, X, Clock, ShieldCheck, Sparkles, GraduationCap, MessageCircle, Save, ChevronRight, AlertTriangle, Star, Eye, EyeOff, Lock, LogOut, Settings, KeyRound } from 'lucide-react';

type Student = { name: string; className: string; level: string; guardian: string; whatsapp: string };
type Attendance = { studentId: string; date: string; className: string; status: 'Presente' | 'Falta' | 'Atraso' | 'Justificada' };
type Grade = { studentId: string; date: string; skill: string; score: number; comment: string };
type NoteRec = { studentId: string; month: string; text: string; teacherName: string };
type AccessRec = { passwordHash: string };
type Rec<T> = { id: string; value: T };
type Tab = 'inicio' | 'alunos' | 'chamada' | 'notas' | 'relatorio' | 'configuracoes';

const SKILLS = ['Speaking', 'Listening', 'Reading', 'Writing', 'Homework', 'Participation', 'Prova'];
const CLASSES = ['Kids 1', 'Kids 2', 'Teens 1', 'Teens 2', 'Adults Basic', 'Adults Intermediate'];
const todayISO = () => new Date().toISOString().slice(0, 10);
const monthOf = (d: string) => d.slice(0, 7);
const fmtDate = (d: string) => { const [y, m, day] = d.split('-'); return `${day}/${m}/${y}`; };
const monthLabel = (m: string) => { const [y, mo] = m.split('-'); const names = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']; return `${names[Number(mo)-1]} de ${y}`; };

async function hashPassword(pw: string): Promise<string> {
  try {
    const enc = new TextEncoder();
    const buf = await crypto.subtle.digest('SHA-256', enc.encode(pw));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch {
    let h = 0;
    for (let i = 0; i < pw.length; i++) { h = ((h << 5) - h + pw.charCodeAt(i)) | 0; }
    return `fallback-${h}`;
  }
}

async function api(action: string, args: any) {
  const res = await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.error) throw new Error(json.error || `Falha na operação (${res.status})`);
  return json.data;
}
const listCol = async <T,>(collection: string): Promise<Rec<T>[]> => {
  const data = await api('records.list', { collection });
  return data.records || [];
};

export default function App() {
  const [tab, setTab] = useState<Tab>('inicio');
  const [students, setStudents] = useState<Rec<Student>[]>([]);
  const [attendance, setAttendance] = useState<Rec<Attendance>[]>([]);
  const [grades, setGrades] = useState<Rec<Grade>[]>([]);
  const [notes, setNotes] = useState<Rec<NoteRec>[]>([]);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState('');
  const [notice, setNotice] = useState('');
  const seeded = useRef(false);

  // Acesso privado — English Nauta
  const [unlocked, setUnlocked] = useState(false);
  const [accessRec, setAccessRec] = useState<Rec<AccessRec> | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'create' | 'confirm-reset' | 'reset'>('login');
  const [loginPw, setLoginPw] = useState('');
  const [showLoginPw, setShowLoginPw] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [authBusy, setAuthBusy] = useState(false);
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [showNewPw, setShowNewPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);
  const [createError, setCreateError] = useState('');
  const [currentPw, setCurrentPw] = useState('');
  const [settingsNewPw, setSettingsNewPw] = useState('');
  const [settingsConfirmPw, setSettingsConfirmPw] = useState('');
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showSettingsNewPw, setShowSettingsNewPw] = useState(false);
  const [showSettingsConfirmPw, setShowSettingsConfirmPw] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState('');
  const [settingsBusy, setSettingsBusy] = useState(false);

  const [search, setSearch] = useState('');
  const [form, setForm] = useState<Student>({ name: '', className: 'Kids 1', level: 'Iniciante', guardian: '', whatsapp: '' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [callDate, setCallDate] = useState(todayISO());
  const [callClass, setCallClass] = useState('Kids 1');
  const [marks, setMarks] = useState<Record<string, Attendance['status']>>({});
  const [savingCall, setSavingCall] = useState(false);
  const [callResult, setCallResult] = useState<{ saved: number; remaining: number; error: string | null; reloadError: string | null } | null>(null);

  const [gradeForm, setGradeForm] = useState({ studentId: '', date: todayISO(), skill: 'Speaking', score: 8, comment: '' });
  const [focusStudent, setFocusStudent] = useState('');
  const [skillFilter, setSkillFilter] = useState('Todas');
  const [showAllGrades, setShowAllGrades] = useState(false);

  const [repStudent, setRepStudent] = useState('');
  const [repMonth, setRepMonth] = useState(new Date().toISOString().slice(0, 7));
  const [obs, setObs] = useState('');
  const [teacherName, setTeacherName] = useState('Flawi');
  const [copied, setCopied] = useState(false);
  const msgRef = useRef<HTMLTextAreaElement>(null);

  const reloadRecords = async () => {
    const [s, a, g, n, acc] = await Promise.all([listCol<Student>('students'), listCol<Attendance>('attendance'), listCol<Grade>('grades'), listCol<NoteRec>('report_notes'), listCol<AccessRec>('access')]);
    setStudents(s); setAttendance(a); setGrades(g); setNotes(n); setAccessRec(acc.length ? acc[0] : null);
  };

  useEffect(() => {
    (async () => {
      try { await reloadRecords(); } catch (e) { setApiError(e instanceof Error ? e.message : 'Não foi possível carregar os dados.'); }
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    if (loading) return;
    if (!accessRec) setAuthMode('create');
    else if (authMode === 'create') setAuthMode('login');
  }, [loading, accessRec]);

  useEffect(() => {
    if (loading || seeded.current) return;
    if (students.length === 0 && !apiError) {
      seeded.current = true;
      (async () => {
        const examples: Student[] = [
          { name: 'Alice Santos', className: 'Kids 1', level: 'Iniciante', guardian: 'Mariana Santos', whatsapp: '(11) 90000-0001' },
          { name: 'Pedro Oliveira', className: 'Teens 2', level: 'Intermediário', guardian: 'Carlos Oliveira', whatsapp: '(11) 90000-0002' },
          { name: 'Sofia Lima', className: 'Kids 2', level: 'Básico', guardian: 'Fernanda Lima', whatsapp: '(11) 90000-0003' },
          { name: 'Miguel Costa', className: 'Adults Basic', level: 'Iniciante', guardian: 'Miguel Costa', whatsapp: '(11) 90000-0004' },
        ];
        try { for (const s of examples) await api('records.create', { collection: 'students', value: s, idempotency_key: `seed-${s.name.replace(/\s/g, '-')}` }); await reloadRecords(); setNotice('4 alunos de exemplo foram adicionados para você testar.'); } catch {}
      })();
    }
    if (students.length && !focusStudent) setFocusStudent(students[0].id);
    if (students.length && !repStudent) setRepStudent(students[0].id);
    if (students.length && !gradeForm.studentId) setGradeForm(f => ({ ...f, studentId: students[0].id }));
  }, [loading, students, apiError]);

  useEffect(() => {
    const rec = notes.find(n => n.value.studentId === repStudent && n.value.month === repMonth);
    setObs(rec?.value.text || '');
    setTeacherName(rec?.value.teacherName || 'Flawi');
  }, [repStudent, repMonth, notes]);

  useEffect(() => {
    const existing = attendance.filter(a => a.value.date === callDate && a.value.className === callClass);
    const m: Record<string, Attendance['status']> = {};
    existing.forEach(a => m[a.value.studentId] = a.value.status);
    setMarks(m); setCallResult(null);
  }, [callDate, callClass, attendance]);

  const currentMonth = new Date().toISOString().slice(0, 7);
  const gradesAvg = (list: Grade[]) => list.length ? list.reduce((s, g) => s + g.score, 0) / list.length : 0;
  const overallAvg = gradesAvg(grades.map(g => g.value));
  const monthAttendance = attendance.filter(a => monthOf(a.value.date) === currentMonth);
  const presentMonth = monthAttendance.filter(a => a.value.status === 'Presente' || a.value.status === 'Atraso').length;
  const attendancePct = monthAttendance.length ? Math.round((presentMonth / monthAttendance.length) * 100) : 0;
  const distinctClasses = [...new Set(students.map(s => s.value.className))];

  const studentStats = (id: string, month?: string) => {
    const att = attendance.filter(a => a.value.studentId === id && (!month || monthOf(a.value.date) === month));
    const gr = grades.filter(g => g.value.studentId === id && (!month || monthOf(g.value.date) === month));
    const pres = att.filter(a => a.value.status === 'Presente' || a.value.status === 'Atraso').length;
    return { total: att.length, pres, faltas: att.filter(a => a.value.status === 'Falta').length, atrasos: att.filter(a => a.value.status === 'Atraso').length, just: att.filter(a => a.value.status === 'Justificada').length, pct: att.length ? Math.round((pres / att.length) * 100) : 0, grades: gr.map(g => g.value), avg: gradesAvg(gr.map(g => g.value)) };
  };
  const alerts = students.map(s => ({ s, st: studentStats(s.id, currentMonth) })).filter(x => x.st.total >= 2 && x.st.pct < 80).sort((a, b) => a.st.pct - b.st.pct);
  const filteredStudents = students.filter(s => s.value.name.toLowerCase().includes(search.toLowerCase()));

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError('');
    if (!accessRec) { setAuthMode('create'); return; }
    if (!loginPw) { setLoginError('Digite sua senha.'); return; }
    setAuthBusy(true);
    try {
      const hash = await hashPassword(loginPw);
      if (hash === accessRec.value.passwordHash) { setUnlocked(true); setLoginPw(''); setTab('inicio'); }
      else setLoginError('Senha incorreta, tente novamente');
    } catch { setLoginError('Não foi possível entrar agora. Tente novamente.'); }
    setAuthBusy(false);
  };

  const handleCreatePassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setCreateError('');
    if (newPw.length < 4) { setCreateError('Escolha uma senha com pelo menos 4 caracteres.'); return; }
    if (newPw !== confirmPw) { setCreateError('As senhas não são iguais. Confira e tente novamente.'); return; }
    setAuthBusy(true);
    try {
      const hash = await hashPassword(newPw);
      const created = await api('records.create', { collection: 'access', value: { passwordHash: hash }, idempotency_key: 'english-nauta-access' });
      setAccessRec(created);
      setUnlocked(true); setNewPw(''); setConfirmPw(''); setAuthMode('login'); setNotice('Senha criada! Bem-vinda ao English Nauta, Flawi.');
    } catch (err) { setCreateError(err instanceof Error ? err.message : 'Não foi possível criar sua senha. Tente novamente.'); }
    setAuthBusy(false);
  };

  const handleResetPassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setCreateError('');
    if (newPw.length < 4) { setCreateError('Escolha uma senha com pelo menos 4 caracteres.'); return; }
    if (newPw !== confirmPw) { setCreateError('As senhas não são iguais. Confira e tente novamente.'); return; }
    setAuthBusy(true);
    try {
      const hash = await hashPassword(newPw);
      let rec: any = accessRec;
      if (rec) rec = await api('records.replace', { collection: 'access', id: rec.id, value: { passwordHash: hash } });
      else rec = await api('records.create', { collection: 'access', value: { passwordHash: hash }, idempotency_key: 'english-nauta-access' });
      setAccessRec(rec);
      setUnlocked(true); setNewPw(''); setConfirmPw(''); setAuthMode('login'); setNotice('Senha redefinida! Você já pode usar a nova senha nos próximos acessos.');
    } catch (err) { setCreateError(err instanceof Error ? err.message : 'Não foi possível redefinir sua senha. Tente novamente.'); }
    setAuthBusy(false);
  };

  const handleChangePassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSettingsMsg('');
    if (!accessRec) { setSettingsMsg('Nenhuma senha salva ainda. Crie sua senha na tela de acesso.'); return; }
    if (settingsNewPw.length < 4) { setSettingsMsg('A nova senha precisa ter pelo menos 4 caracteres.'); return; }
    if (settingsNewPw !== settingsConfirmPw) { setSettingsMsg('A nova senha e a confirmação não são iguais.'); return; }
    setSettingsBusy(true);
    try {
      const currentHash = await hashPassword(currentPw);
      if (currentHash !== accessRec.value.passwordHash) { setSettingsMsg('Senha atual incorreta. Tente novamente.'); setSettingsBusy(false); return; }
      const newHash = await hashPassword(settingsNewPw);
      const updated = await api('records.replace', { collection: 'access', id: accessRec.id, value: { passwordHash: newHash } });
      setAccessRec(updated); setCurrentPw(''); setSettingsNewPw(''); setSettingsConfirmPw(''); setSettingsMsg('Senha alterada com sucesso! Use a nova senha no próximo acesso.');
    } catch (err) { setSettingsMsg(err instanceof Error ? err.message : 'Não foi possível alterar a senha.'); }
    setSettingsBusy(false);
  };

  const lockApp = () => { setUnlocked(false); setLoginPw(''); setLoginError(''); setAuthMode(accessRec ? 'login' : 'create'); setTab('inicio'); };

  const saveStudent = async () => {
    if (!form.name.trim() || !form.guardian.trim()) { setNotice('Preencha nome do aluno e nome do responsável.'); return; }
    try {
      if (editingId) await api('records.replace', { collection: 'students', id: editingId, value: form });
      else await api('records.create', { collection: 'students', value: form, idempotency_key: `student-${Date.now()}` });
      await reloadRecords(); setForm({ name: '', className: 'Kids 1', level: 'Iniciante', guardian: '', whatsapp: '' }); setEditingId(null); setNotice(editingId ? 'Aluno atualizado com sucesso.' : 'Aluno cadastrado com sucesso.');
    } catch (e) { setNotice(e instanceof Error ? e.message : 'Não foi possível salvar o aluno.'); }
  };
  const removeStudent = async (id: string) => {
    try { await api('records.delete', { collection: 'students', id }); await reloadRecords(); setDeleteId(null); setNotice('Aluno excluído.'); } catch (e) { setNotice(e instanceof Error ? e.message : 'Não foi possível excluir.'); }
  };

  const saveCall = async () => {
    const rows = students.filter(s => s.value.className === callClass);
    if (!rows.length) { setNotice('Nenhum aluno nesta turma.'); return; }
    const createRow = async (row: Rec<Student>) => {
      const status = marks[row.id] || 'Presente';
      const val: Attendance = { studentId: row.id, date: callDate, className: callClass, status };
      const existing = attendance.find(a => a.value.studentId === row.id && a.value.date === callDate);
      if (existing) await api('records.replace', { collection: 'attendance', id: existing.id, value: val });
      else await api('records.create', { collection: 'attendance', value: val, idempotency_key: `att-${row.id}-${callDate}` });
    };
    setSavingCall(true); let saved = 0; let error: string | null = null;
    try { for (const row of rows) { await createRow(row); saved += 1; } } catch (e) { error = e instanceof Error ? e.message : String(e); }
    let reloadError: string | null = null;
    try { await reloadRecords(); } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setCallResult({ saved, remaining: rows.length - saved, error, reloadError }); setSavingCall(false);
  };

  const saveGrade = async () => {
    if (!gradeForm.studentId) return;
    try {
      await api('records.create', { collection: 'grades', value: { studentId: gradeForm.studentId, date: gradeForm.date, skill: gradeForm.skill, score: Number(gradeForm.score), comment: gradeForm.comment }, idempotency_key: `grade-${gradeForm.studentId}-${gradeForm.date}-${Date.now()}` });
      await reloadRecords(); setGradeForm(f => ({ ...f, comment: '' })); setNotice('Nota lançada com sucesso.');
    } catch (e) { setNotice(e instanceof Error ? e.message : 'Não foi possível lançar a nota.'); }
  };

  const saveNote = async () => {
    if (!repStudent) return;
    const val: NoteRec = { studentId: repStudent, month: repMonth, text: obs, teacherName };
    try {
      const existing = notes.find(n => n.value.studentId === repStudent && n.value.month === repMonth);
      if (existing) await api('records.replace', { collection: 'report_notes', id: existing.id, value: val });
      else await api('records.create', { collection: 'report_notes', value: val, idempotency_key: `note-${repStudent}-${repMonth}` });
      await reloadRecords(); setNotice('Observações do relatório salvas.');
    } catch (e) { setNotice(e instanceof Error ? e.message : 'Não foi possível salvar as observações.'); }
  };

  const focus = students.find(s => s.id === focusStudent);
  const focusGrades = grades.filter(g => g.value.studentId === focusStudent && (skillFilter === 'Todas' || g.value.skill === skillFilter)).map(g => g.value);
  const byDate = useMemo(() => {
    const map = new Map<string, number[]>();
    focusGrades.forEach(g => { const arr = map.get(g.date) || []; arr.push(g.score); map.set(g.date, arr); });
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([date, arr]) => ({ date: fmtDate(date), media: Number((arr.reduce((s, x) => s + x, 0) / arr.length).toFixed(1)) }));
  }, [focusGrades]);
  const skillAvgs = SKILLS.map(skill => { const list = grades.filter(g => g.value.studentId === focusStudent && g.value.skill === skill).map(g => g.value.score); return { skill, media: list.length ? Number((list.reduce((a, b) => a + b, 0) / list.length).toFixed(1)) : 0, total: list.length }; });

  const rep = students.find(s => s.id === repStudent);
  const repStats = repStudent ? studentStats(repStudent, repMonth) : null;
  const repBySkill = repStudent ? SKILLS.map(skill => { const list = grades.filter(g => g.value.studentId === repStudent && g.value.skill === skill && monthOf(g.value.date) === repMonth).map(g => g.value.score); return { skill, media: list.length ? (list.reduce((a, b) => a + b, 0) / list.length).toFixed(1) : '—', total: list.length }; }).filter(x => x.total > 0) : [];
  const repEvolution = repStudent ? (() => { const map = new Map<string, number[]>(); grades.filter(g => g.value.studentId === repStudent && monthOf(g.value.date) === repMonth).forEach(g => { const a = map.get(g.value.date) || []; a.push(g.value.score); map.set(g.value.date, a); }); return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([d, a]) => ({ date: fmtDate(d), media: Number((a.reduce((s, x) => s + x, 0) / a.length).toFixed(1)) })); })() : [];
  const whatsappText = rep ? `Olá, ${rep.value.guardian}! Tudo bem? Segue o resumo de ${monthLabel(repMonth)} de ${rep.value.name} (${rep.value.className}) na English Nauta. 📚\n\nPresença: ${repStats?.pct}% — ${repStats?.total} aulas, ${repStats?.pres} presenças, ${repStats?.faltas} faltas e ${repStats?.atrasos} atrasos.\nMédia geral do mês: ${repStats ? repStats.avg.toFixed(1) : '—'} / 10.\n\n${obs || 'Continue incentivando a prática em casa — um pouquinho por dia faz muita diferença!'}\n\nQualquer dúvida, estou à disposição. 💜\n${teacherName} · English Nauta` : '';
  const copyWhats = () => { if (msgRef.current) { msgRef.current.select(); document.execCommand('copy'); setCopied(true); setTimeout(() => setCopied(false), 2500); } };

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'inicio', label: 'Visão geral', icon: <Sparkles size={19} /> },
    { id: 'alunos', label: 'Alunos', icon: <Users size={19} /> },
    { id: 'chamada', label: 'Chamada', icon: <CalendarCheck size={19} /> },
    { id: 'notas', label: 'Notas & evolução', icon: <TrendingUp size={19} /> },
    { id: 'relatorio', label: 'Relatório mensal', icon: <BookOpen size={19} /> },
    { id: 'configuracoes', label: 'Configurações', icon: <Settings size={19} /> },
  ];

  const isCreate = !accessRec || authMode === 'create';
  return (
    <div data-safe-area-inset-root className="min-h-screen" style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', background: 'var(--surface)', color: 'var(--ink)' }}>
      {loading ? (
        <div className="min-h-screen grid place-items-center"><p className="font-bold text-lg px-6 text-center">Carregando seu painel… 💜</p></div>
      ) : !unlocked ? (
        <main className="min-h-screen grid place-items-center px-4 py-8">
          <div className="w-full max-w-md">
            <div className="text-center mb-6">
              <div className="mx-auto w-16 h-16 rounded-[20px] grid place-items-center text-3xl font-black shadow-sm" style={{ background: 'var(--accent)' }}>EN</div>
              <h1 className="font-display text-[clamp(1.9rem,8vw,2.6rem)] font-black leading-none mt-4">English Nauta</h1>
              <p className="font-extrabold mt-2" style={{ color: 'var(--primary)' }}>Acesso da Professora</p>
              <p className="text-sm font-bold mt-1" style={{ color: 'var(--muted)' }}>Professora: Flawi · Somente você tem acesso a este painel.</p>
            </div>

            <section className="p-5 sm:p-6 rounded-[28px] border shadow-sm" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              {isCreate ? (
                <>
                  <div className="flex items-center gap-2"><Lock size={20} style={{ color: 'var(--primary)' }} /><h2 className="font-black text-xl">Crie sua senha de acesso</h2></div>
                  <p className="text-sm font-semibold mt-1" style={{ color: 'var(--muted)' }}>É o seu primeiro acesso. Crie uma senha só sua — não existe nenhuma senha pronta. Você vai usá-la para entrar nas próximas vezes.</p>
                  <form onSubmit={handleCreatePassword} className="mt-4">
                    <label className="block text-xs font-black mb-1" htmlFor="create-pw">Criar senha</label>
                    <div className="relative mb-3"><input id="create-pw" type={showNewPw ? 'text' : 'password'} className="field !pr-12" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="Escolha uma senha com 4 ou mais caracteres" autoComplete="new-password" /><button type="button" onClick={() => setShowNewPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-sm" aria-label={showNewPw ? 'Ocultar senha' : 'Mostrar senha'}>{showNewPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
                    <label className="block text-xs font-black mb-1" htmlFor="confirm-pw">Confirmar senha</label>
                    <div className="relative mb-3"><input id="confirm-pw" type={showConfirmPw ? 'text' : 'password'} className="field !pr-12" value={confirmPw} onChange={e => setConfirmPw(e.target.value)} placeholder="Repita a senha" autoComplete="new-password" /><button type="button" onClick={() => setShowConfirmPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showConfirmPw ? 'Ocultar confirmação' : 'Mostrar confirmação'}>{showConfirmPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
                    {createError && <p className="text-sm font-bold mb-3" style={{ color: 'var(--bad)' }}>{createError}</p>}
                    <button disabled={authBusy} className="btn-primary w-full flex justify-center gap-2 items-center"><KeyRound size={18} />{authBusy ? 'Criando senha…' : 'Criar senha e entrar'}</button>
                    <p className="text-xs font-bold mt-3 text-center" style={{ color: 'var(--muted)' }}>Guarde sua senha em um lugar seguro. Se esquecer, você poderá redefinir na tela de acesso.</p>
                  </form>
                </>
              ) : authMode === 'confirm-reset' ? (
                <>
                  <h2 className="font-black text-xl">Esqueci minha senha</h2>
                  <p className="text-sm font-semibold mt-2" style={{ color: 'var(--muted)' }}>Para não ficar trancada para fora, você pode redefinir sua senha agora. Confirme que é você para continuar.</p>
                  <div className="mt-4 grid gap-2"><button onClick={() => { setCreateError(''); setNewPw(''); setConfirmPw(''); setAuthMode('reset'); }} className="btn-primary w-full">Sim, sou eu, redefinir</button><button onClick={() => setAuthMode('login')} className="btn-ghost w-full">Voltar para entrar</button></div>
                </>
              ) : authMode === 'reset' ? (
                <>
                  <h2 className="font-black text-xl">Redefinir sua senha</h2>
                  <p className="text-sm font-semibold mt-1" style={{ color: 'var(--muted)' }}>Crie uma nova senha e entre com ela.</p>
                  <form onSubmit={handleResetPassword} className="mt-4">
                    <label className="block text-xs font-black mb-1" htmlFor="reset-pw">Nova senha</label>
                    <div className="relative mb-3"><input id="reset-pw" type={showNewPw ? 'text' : 'password'} className="field !pr-12" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="Nova senha" autoComplete="new-password" /><button type="button" onClick={() => setShowNewPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showNewPw ? 'Ocultar senha' : 'Mostrar senha'}>{showNewPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
                    <label className="block text-xs font-black mb-1" htmlFor="reset-confirm">Confirmar nova senha</label>
                    <div className="relative mb-3"><input id="reset-confirm" type={showConfirmPw ? 'text' : 'password'} className="field !pr-12" value={confirmPw} onChange={e => setConfirmPw(e.target.value)} placeholder="Repita a nova senha" autoComplete="new-password" /><button type="button" onClick={() => setShowConfirmPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showConfirmPw ? 'Ocultar confirmação' : 'Mostrar confirmação'}>{showConfirmPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
                    {createError && <p className="text-sm font-bold mb-3" style={{ color: 'var(--bad)' }}>{createError}</p>}
                    <button disabled={authBusy} className="btn-primary w-full">{authBusy ? 'Redefinindo…' : 'Redefinir senha e entrar'}</button>
                    <button type="button" onClick={() => setAuthMode('login')} className="btn-ghost w-full mt-2">Voltar para entrar</button>
                  </form>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2"><ShieldCheck size={20} style={{ color: 'var(--primary)' }} /><h2 className="font-black text-xl">Bem-vinda de volta, Flawi!</h2></div>
                  <p className="text-sm font-semibold mt-1" style={{ color: 'var(--muted)' }}>Digite sua senha para entrar no painel do English Nauta.</p>
                  <form onSubmit={handleLogin} className="mt-4">
                    <label className="block text-xs font-black mb-1" htmlFor="login-pw">Senha</label>
                    <div className="relative mb-3"><input id="login-pw" type={showLoginPw ? 'text' : 'password'} className="field !pr-12" value={loginPw} onChange={e => { setLoginPw(e.target.value); setLoginError(''); }} placeholder="Sua senha" autoComplete="current-password" /><button type="button" onClick={() => setShowLoginPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showLoginPw ? 'Ocultar senha' : 'Mostrar senha'}>{showLoginPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
                    {loginError && <p className="text-sm font-bold mb-3" role="alert" style={{ color: 'var(--bad)' }}>{loginError}</p>}
                    <button disabled={authBusy} className="btn-primary w-full flex justify-center gap-2 items-center"><Lock size={18} />{authBusy ? 'Entrando…' : 'Entrar'}</button>
                  </form>
                  <button onClick={() => { setLoginError(''); setAuthMode('confirm-reset'); }} className="w-full mt-3 text-sm font-extrabold underline underline-offset-2" style={{ color: 'var(--primary)' }}>Esqueci minha senha</button>
                </>
              )}
            </section>
            {apiError && <p className="mt-4 p-4 rounded-2xl font-bold text-sm text-center" style={{ background: '#FEE4E4', color: '#7F1D1D' }}>O acesso está indisponível no momento: {apiError}</p>}
            <p className="text-center text-xs font-bold mt-4" style={{ color: 'var(--muted)' }}>English Nauta · Acesso privado da professora</p>
          </div>
        </main>
      ) : (
        <>
      <header data-safe-area-sticky-top className="sticky z-30 no-print" style={{ top: 'var(--safe-area-inset-top)', background: 'var(--surface)', borderBottom: '1px solid var(--line)' }}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3"><div className="w-11 h-11 rounded-2xl grid place-items-center text-lg font-black shrink-0" style={{ background: 'var(--accent)' }}>EN</div><div><h1 className="font-display text-[clamp(1.25rem,4vw,1.9rem)] leading-none font-black">English Nauta <span style={{ color: 'var(--primary)' }}>- Painel da Teacher</span></h1><p className="text-xs sm:text-sm font-bold" style={{ color: 'var(--muted)' }}>Professora: Flawi · Chamada, evolução e relatório — tudo em um lugar.</p></div></div>
          <div className="flex items-center gap-2 flex-wrap"><div className="chip" style={{ background: 'var(--surface-3)' }}>✦ {monthLabel(currentMonth)}</div><button onClick={lockApp} className="btn-ghost !py-2.5 !px-3 text-sm flex items-center gap-2"><LogOut size={17} /> Sair / Bloquear</button></div>
        </div>
        <nav className="max-w-6xl mx-auto px-4 sm:px-6 pb-3 flex gap-2 overflow-x-auto">
          {tabs.map(t => <button key={t.id} onClick={() => setTab(t.id)} className="shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-full font-extrabold text-sm" style={tab === t.id ? { background: 'var(--primary)', color: 'white' } : { background: 'var(--surface-2)', color: 'var(--ink)' }}>{t.icon}{t.label}</button>)}
        </nav>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 overflow-x-clip">
        {apiError && <div className="no-print mb-4 p-4 rounded-2xl font-bold text-sm" style={{ background: '#FEE4E4', color: '#7F1D1D' }}>O salvamento está indisponível no momento: {apiError}. Seus dados serão carregados novamente quando o serviço voltar.</div>}
        {notice && <div className="no-print mb-4 flex justify-between gap-3 p-4 rounded-2xl font-bold text-sm" style={{ background: 'var(--surface-3)' }}><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Fechar aviso"><X size={18} /></button></div>}

        {tab === 'inicio' && (
          <section>
            <div className="flex flex-wrap items-end justify-between gap-3 mb-5"><div><p className="font-black tracking-wide text-xs uppercase" style={{ color: 'var(--primary)' }}>English Nauta · Bom dia, Flawi!</p><h2 className="font-display text-[clamp(1.8rem,6vw,3rem)] leading-[1.05] font-black">Como está a sua<br />turma hoje?</h2><p className="text-sm font-bold mt-2" style={{ color: 'var(--muted)' }}>English Nauta - Painel da Teacher · Professora: Flawi</p></div><button onClick={() => setTab('chamada')} className="btn-yellow flex items-center gap-2">Fazer chamada de hoje <ChevronRight size={18} /></button></div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              {[{ label: 'Total de alunos', value: students.length, icon: <Users />, bg: 'var(--surface-2)' }, { label: 'Turmas ativas', value: distinctClasses.length, icon: <GraduationCap />, bg: 'var(--surface-3)' }, { label: 'Média geral', value: overallAvg ? `${overallAvg.toFixed(1)} / 10` : '—', icon: <Star />, bg: '#FFE9EF' }, { label: 'Presença no mês', value: `${attendancePct}%`, icon: <CalendarCheck />, bg: '#E2F7ED' }].map((c, i) => <div key={i} className="p-4 sm:p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><div className="w-10 h-10 rounded-xl grid place-items-center mb-3" style={{ background: c.bg }}>{c.icon}</div><div className="text-2xl sm:text-3xl font-black">{c.value}</div><div className="text-xs sm:text-sm font-bold" style={{ color: 'var(--muted)' }}>{c.label}</div></div>)}
            </div>
            <div className="grid lg:grid-cols-5 gap-4 mt-5">
              <div className="lg:col-span-3 p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><h3 className="font-black text-lg flex gap-2 items-center"><AlertTriangle size={20} style={{ color: 'var(--accent)' }} /> Atenção: faltas em destaque</h3><p className="text-sm font-semibold" style={{ color: 'var(--muted)' }}>Alunos com presença abaixo de 80% neste mês.</p>
                <div className="mt-4 space-y-3">{alerts.length === 0 ? <p className="p-4 rounded-2xl font-bold" style={{ background: 'var(--surface-2)' }}>Nenhum alerta por aqui. 🎉 Continue assim!</p> : alerts.map(({ s, st }) => <button key={s.id} onClick={() => { setRepStudent(s.id); setTab('relatorio'); }} className="w-full flex items-center justify-between gap-3 text-left p-3 rounded-2xl" style={{ background: 'var(--surface-2)' }}><span><span className="block font-extrabold">{s.value.name}</span><span className="text-xs font-bold" style={{ color: 'var(--muted)' }}>{s.value.className} · {st.faltas} falta(s) · {st.total} aula(s)</span></span><span className="font-black" style={{ color: 'var(--bad)' }}>{st.pct}%</span></button>)}</div>
              </div>
              <div className="lg:col-span-2 p-5 rounded-3xl" style={{ background: 'var(--primary)', color: 'white' }}><h3 className="font-black text-lg">Próximo passo</h3><p className="text-sm opacity-90 mt-1">Lance a chamada e uma nota de participação. O relatório do mês se monta sozinho.</p><div className="mt-4 flex flex-wrap gap-2"><button onClick={() => setTab('chamada')} className="btn-yellow !py-2.5 text-sm">Chamada</button><button onClick={() => setTab('notas')} className="px-4 py-2.5 rounded-[14px] bg-white/20 font-extrabold text-sm">Lançar nota</button></div><p className="mt-5 text-xs font-bold opacity-80">English Nauta · Armazenamento: até 1.000 registros no total do app. Cada aluno, chamada e nota conta como um registro.</p></div>
            </div>
            <div className="mt-5 p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><h3 className="font-black text-lg mb-3">Alunos em destaque</h3><div className="grid sm:grid-cols-2 gap-3">{students.slice(0, 4).map(s => { const st = studentStats(s.id); return <button key={s.id} onClick={() => { setFocusStudent(s.id); setTab('notas'); }} className="flex justify-between items-center text-left p-4 rounded-2xl" style={{ background: 'var(--surface-2)' }}><span><span className="block font-extrabold">{s.value.name}</span><span className="text-xs font-bold" style={{ color: 'var(--muted)' }}>{s.value.className} · {s.value.level}</span></span><span className="text-right"><span className="block font-black">{st.avg ? st.avg.toFixed(1) : '—'}</span><span className="text-xs font-bold" style={{ color: 'var(--muted)' }}>média · {st.pct}% presença</span></span></button>; })}</div></div>
          </section>
        )}

        {tab === 'alunos' && (
          <section className="grid lg:grid-cols-5 gap-5">
            <form onSubmit={e => { e.preventDefault(); saveStudent(); }} className="lg:col-span-2 p-5 rounded-3xl border h-fit" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              <h2 className="font-display text-2xl font-black">{editingId ? 'Editar aluno' : 'Cadastrar novo aluno'}</h2><p className="text-sm font-semibold mb-4" style={{ color: 'var(--muted)' }}>Os dados ficam salvos para as próximas aulas.</p>
              <label className="block text-xs font-black mb-1">Nome completo *</label><input className="field mb-3" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Ex.: Alice Santos" />
              <div className="grid grid-cols-2 gap-3"><div><label className="block text-xs font-black mb-1">Turma</label><select className="field" value={form.className} onChange={e => setForm({ ...form, className: e.target.value })}>{CLASSES.map(c => <option key={c}>{c}</option>)}</select></div><div><label className="block text-xs font-black mb-1">Nível</label><select className="field" value={form.level} onChange={e => setForm({ ...form, level: e.target.value })}>{['Iniciante', 'Básico', 'Intermediário', 'Avançado'].map(c => <option key={c}>{c}</option>)}</select></div></div>
              <label className="block text-xs font-black mt-3 mb-1">Nome do responsável *</label><input className="field mb-3" value={form.guardian} onChange={e => setForm({ ...form, guardian: e.target.value })} placeholder="Quem recebe o relatório" />
              <label className="block text-xs font-black mb-1">WhatsApp do responsável</label><input className="field mb-4" value={form.whatsapp} onChange={e => setForm({ ...form, whatsapp: e.target.value })} placeholder="(11) 90000-0000" />
              <button className="btn-primary w-full flex justify-center gap-2 items-center">{editingId ? <Save size={18} /> : <Plus size={18} />}{editingId ? 'Salvar alterações' : 'Cadastrar aluno'}</button>
              {editingId && <button type="button" onClick={() => { setEditingId(null); setForm({ name: '', className: 'Kids 1', level: 'Iniciante', guardian: '', whatsapp: '' }); }} className="btn-ghost w-full mt-2">Cancelar edição</button>}
            </form>
            <div className="lg:col-span-3"><div className="relative mb-3"><Search className="absolute left-4 top-1/2 -translate-y-1/2" size={18} /><input className="field !pl-11" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar aluno por nome…" /></div><p className="text-sm font-bold mb-3" style={{ color: 'var(--muted)' }}>{filteredStudents.length} aluno(s) encontrado(s)</p><div className="space-y-3">{filteredStudents.map(s => { const st = studentStats(s.id); return <article key={s.id} className="p-4 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><div className="flex flex-wrap justify-between gap-3"><div><h3 className="font-black text-lg">{s.value.name}</h3><p className="text-sm font-bold" style={{ color: 'var(--muted)' }}>{s.value.className} · {s.value.level} · Responsável: {s.value.guardian}</p><p className="text-sm font-bold">WhatsApp: {s.value.whatsapp || '—'}</p></div><div className="flex gap-2 h-fit"><button onClick={() => { setEditingId(s.id); setForm(s.value); }} className="btn-ghost !p-2.5" aria-label={`Editar ${s.value.name}`}><Pencil size={18} /></button><button onClick={() => setDeleteId(s.id)} className="p-2.5 rounded-[14px] bg-red-50 text-red-600 font-bold" aria-label={`Excluir ${s.value.name}`}><Trash2 size={18} /></button></div></div><div className="mt-3 flex gap-2 flex-wrap"><span className="chip" style={{ background: 'var(--surface-2)' }}>Média {st.avg ? st.avg.toFixed(1) : '—'}</span><span className="chip" style={{ background: 'var(--surface-3)' }}>Presença {st.pct}%</span><span className="chip" style={{ background: '#FFE9EF' }}>{st.faltas} falta(s)</span></div>{deleteId === s.id && <div className="mt-3 p-3 rounded-2xl flex flex-wrap gap-2 items-center justify-between" style={{ background: '#FEF2F2' }}><span className="font-bold text-sm">Excluir {s.value.name}?</span><span className="flex gap-2"><button onClick={() => removeStudent(s.id)} className="px-3 py-2 rounded-lg bg-red-600 text-white font-extrabold text-sm">Excluir</button><button onClick={() => setDeleteId(null)} className="px-3 py-2 rounded-lg bg-white font-extrabold text-sm">Manter</button></span></div>}</article>; })}</div></div>
          </section>
        )}

        {tab === 'chamada' && (
          <section>
            <div className="p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              <div className="flex flex-wrap justify-between gap-3 items-end"><div><h2 className="font-display text-2xl sm:text-3xl font-black">Chamada do dia</h2><p className="text-sm font-semibold" style={{ color: 'var(--muted)' }}>Marque cada aluno e salve. Você pode voltar e corrigir a mesma data.</p></div><button onClick={() => { const m: Record<string, Attendance['status']> = {}; students.filter(s => s.value.className === callClass).forEach(s => m[s.id] = 'Presente'); setMarks(m); }} className="btn-yellow">Marcar todos como presentes</button></div>
              <div className="grid sm:grid-cols-2 gap-3 mt-4"><label className="text-xs font-black">Data<input type="date" className="field mt-1" value={callDate} onChange={e => setCallDate(e.target.value)} /></label><label className="text-xs font-black">Turma<select className="field mt-1" value={callClass} onChange={e => setCallClass(e.target.value)}>{CLASSES.map(c => <option key={c}>{c}</option>)}</select></label></div>
              <div className="mt-5 space-y-3">{students.filter(s => s.value.className === callClass).map(s => <div key={s.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-2xl" style={{ background: 'var(--surface-2)' }}><div><p className="font-extrabold">{s.value.name}</p><p className="text-xs font-bold" style={{ color: 'var(--muted)' }}>Presença no mês: {studentStats(s.id, monthOf(callDate)).pct}%</p></div><div className="grid grid-cols-4 gap-1.5 w-full sm:w-auto">{(['Presente', 'Falta', 'Atraso', 'Justificada'] as const).map(st => <button key={st} onClick={() => setMarks(m => ({ ...m, [s.id]: st }))} className="px-2 py-2.5 rounded-xl text-xs sm:text-sm font-extrabold" style={marks[s.id] === st ? { background: st === 'Presente' ? 'var(--good)' : st === 'Falta' ? 'var(--bad)' : st === 'Atraso' ? 'var(--accent)' : 'var(--primary)', color: st === 'Atraso' ? '#241A38' : 'white' } : { background: 'var(--card)', color: 'var(--ink)' }}>{st === 'Presente' ? '✓ Presente' : st}</button>)}</div></div>)}{students.filter(s => s.value.className === callClass).length === 0 && <p className="font-bold p-4 rounded-2xl" style={{ background: 'var(--surface-3)' }}>Nenhum aluno nesta turma ainda. Cadastre um aluno em Alunos.</p>}</div>
              <button onClick={saveCall} disabled={savingCall} className="btn-primary w-full mt-4 flex justify-center gap-2 items-center"><Check size={19} />{savingCall ? 'Salvando chamada…' : 'Salvar chamada'}</button>
              {callResult && <p className="mt-3 text-sm font-bold">{callResult.saved} registro(s) salvo(s) · {callResult.remaining} restante(s){callResult.error ? ` · Erro: ${callResult.error}` : ''}{callResult.reloadError ? ` · Erro ao recarregar: ${callResult.reloadError}` : ''}</p>}
            </div>
            <div className="mt-5 p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><h3 className="font-black text-lg flex gap-2 items-center"><Clock size={19} /> Histórico recente</h3><div className="mt-3 space-y-2">{[...attendance].sort((a, b) => b.value.date.localeCompare(a.value.date)).slice(0, 10).map(a => { const st = students.find(s => s.id === a.value.studentId); return <div key={a.id} className="flex justify-between gap-3 text-sm font-bold"><span>{fmtDate(a.value.date)} · {st?.value.name || 'Aluno'} · {a.value.className}</span><span style={{ color: a.value.status === 'Falta' ? 'var(--bad)' : 'var(--good)' }}>{a.value.status}</span></div>; })}{attendance.length === 0 && <p className="text-sm font-semibold" style={{ color: 'var(--muted)' }}>Ainda não há chamadas salvas.</p>}</div></div>
          </section>
        )}

        {tab === 'notas' && (
          <section className="grid lg:grid-cols-5 gap-5">
            <form onSubmit={e => { e.preventDefault(); saveGrade(); }} className="lg:col-span-2 p-5 rounded-3xl border h-fit" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              <h2 className="font-display text-2xl font-black">Lançar nota</h2><p className="text-sm font-semibold mb-4" style={{ color: 'var(--muted)' }}>Uma nota por vez, com carinho e contexto.</p>
              <label className="block text-xs font-black mb-1">Aluno</label><select className="field mb-3" value={gradeForm.studentId} onChange={e => setGradeForm({ ...gradeForm, studentId: e.target.value })}>{students.map(s => <option key={s.id} value={s.id}>{s.value.name} · {s.value.className}</option>)}</select>
              <div className="grid grid-cols-2 gap-3"><label className="text-xs font-black">Data<input type="date" className="field mt-1" value={gradeForm.date} onChange={e => setGradeForm({ ...gradeForm, date: e.target.value })} /></label><label className="text-xs font-black">Nota (0 a 10)<input type="number" min={0} max={10} step={0.5} className="field mt-1" value={gradeForm.score} onChange={e => setGradeForm({ ...gradeForm, score: Number(e.target.value) })} /></label></div>
              <label className="block text-xs font-black mt-3 mb-1">Habilidade</label><select className="field mb-3" value={gradeForm.skill} onChange={e => setGradeForm({ ...gradeForm, skill: e.target.value })}>{SKILLS.map(s => <option key={s}>{s}</option>)}</select>
              <label className="block text-xs font-black mb-1">Comentário curto</label><input className="field mb-4" value={gradeForm.comment} onChange={e => setGradeForm({ ...gradeForm, comment: e.target.value })} placeholder="Ex.: Arrasou no vocabulário novo!" />
              <button className="btn-primary w-full">Lançar nota</button>
            </form>
            <div className="lg:col-span-3 space-y-4">
              <div className="p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><div className="flex flex-wrap justify-between gap-3"><div><label className="block text-xs font-black mb-1">Ver evolução de</label><select className="field !w-auto" value={focusStudent} onChange={e => setFocusStudent(e.target.value)}>{students.map(s => <option key={s.id} value={s.id}>{s.value.name}</option>)}</select></div><div><label className="block text-xs font-black mb-1">Filtrar habilidade</label><select className="field !w-auto" value={skillFilter} onChange={e => setSkillFilter(e.target.value)}><option>Todas</option>{SKILLS.map(s => <option key={s}>{s}</option>)}</select></div></div>
                <div className="mt-4 flex gap-3 flex-wrap"><span className="text-3xl font-black">{focusGrades.length ? (focusGrades.reduce((s, g) => s + g.score, 0) / focusGrades.length).toFixed(1) : '—'}</span><span className="self-center text-sm font-bold" style={{ color: 'var(--muted)' }}>média geral<br />{focusGrades.length} nota(s)</span></div>
                <h4 className="font-black mt-5 mb-2">Média por habilidade</h4><div className="space-y-2">{skillAvgs.map(s => <div key={s.skill} className="grid grid-cols-[110px_1fr_36px] items-center gap-2 text-xs font-bold"><span>{s.skill}</span><div className="h-3 rounded-full overflow-hidden" style={{ background: 'var(--surface-2)' }}><div className="h-full rounded-full" style={{ width: `${s.media * 10}%`, background: 'var(--primary)' }} /></div><span className="text-right">{s.media || '—'}</span></div>)}</div>
                <h4 className="font-black mt-6 mb-2">Evolução da média ao longo do tempo</h4>{byDate.length ? <div className="h-56"><ResponsiveContainer width="100%" height="100%"><LineChart data={byDate}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" fontSize={12} /><YAxis domain={[0, 10]} fontSize={12} /><Tooltip /><Line type="monotone" dataKey="media" stroke="#6C3FC5" strokeWidth={3} dot={{ fill: '#FFC93C', r: 5 }} /></LineChart></ResponsiveContainer></div> : <p className="text-sm font-semibold" style={{ color: 'var(--muted)' }}>Lance a primeira nota para ver a evolução aqui.</p>}
              </div>
              <div className="p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><button onClick={() => setShowAllGrades(v => !v)} className="w-full flex justify-between font-black">{showAllGrades ? 'Ocultar notas lançadas' : 'Ver notas lançadas'}<ChevronRight size={18} /></button>{showAllGrades && <div className="mt-3 space-y-2">{grades.filter(g => g.value.studentId === focusStudent).sort((a, b) => b.value.date.localeCompare(a.value.date)).slice(0, 20).map(g => <div key={g.id} className="flex justify-between gap-3 text-sm font-bold"><span>{fmtDate(g.value.date)} · {g.value.skill}{g.value.comment ? ` — ${g.value.comment}` : ''}</span><span>{g.value.score.toFixed(1)}</span></div>)}</div>}</div>
            </div>
          </section>
        )}

        {tab === 'relatorio' && (
          <section>
            <div className="no-print p-5 rounded-3xl border mb-5" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><h2 className="font-display text-2xl sm:text-3xl font-black">English Nauta - Relatório Mensal de Inglês</h2><p className="text-sm font-semibold" style={{ color: 'var(--muted)' }}>Escolha o aluno e o mês. O relatório é montado com os dados já lançados.</p><div className="grid sm:grid-cols-2 gap-3 mt-4"><label className="text-xs font-black">Aluno<select className="field mt-1" value={repStudent} onChange={e => setRepStudent(e.target.value)}>{students.map(s => <option key={s.id} value={s.id}>{s.value.name} · {s.value.className}</option>)}</select></label><label className="text-xs font-black">Mês / ano<input type="month" className="field mt-1" value={repMonth} onChange={e => setRepMonth(e.target.value)} /></label></div></div>

            {rep && repStats ? (
              <article className="print-area rounded-[28px] border bg-white text-[#241A38] p-5 sm:p-9 shadow-sm" style={{ borderColor: 'var(--line)' }}>
                <div className="flex justify-between gap-4 border-b-2 pb-5" style={{ borderColor: '#6C3FC5' }}><div><p className="text-xs font-black tracking-[0.2em] uppercase" style={{ color: '#6C3FC5' }}>English Nauta - Relatório Mensal de Inglês</p><h3 className="font-display text-[clamp(1.6rem,6vw,2.6rem)] font-black leading-tight">{rep.value.name}</h3><p className="font-bold text-sm">{rep.value.className} · Nível {rep.value.level} · {monthLabel(repMonth)} · Professora: Flawi</p></div><div className="text-right shrink-0"><div className="w-14 h-14 rounded-2xl grid place-items-center text-2xl font-black" style={{ background: '#FFC93C' }}>★</div><p className="text-xs font-black mt-1">Keep going!</p></div></div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-5">{[{ l: 'Aulas', v: repStats.total }, { l: 'Presenças', v: repStats.pres }, { l: 'Faltas', v: repStats.faltas }, { l: 'Presença', v: `${repStats.pct}%` }].map((x, i) => <div key={i} className="p-4 rounded-2xl bg-[#F5F0FF]"><div className="text-2xl font-black">{x.v}</div><div className="text-xs font-black uppercase">{x.l}</div></div>)}</div>
                <p className="text-sm font-bold mb-4">Atrasos: {repStats.atrasos} · Justificadas: {repStats.just} · Responsável: {rep.value.guardian}</p>
                <h4 className="font-black text-lg">Notas do mês por habilidade</h4>
                <div className="overflow-x-auto mt-2"><table className="w-full text-sm min-w-[420px]"><thead><tr className="text-left border-b"><th className="py-2">Habilidade</th><th>Atividades</th><th>Média</th></tr></thead><tbody>{repBySkill.length ? repBySkill.map(r => <tr key={r.skill} className="border-b"><td className="py-2 font-bold">{r.skill}</td><td>{r.total}</td><td className="font-black">{r.media}</td></tr>) : <tr><td colSpan={3} className="py-3">Nenhuma nota lançada neste mês.</td></tr>}<tr className="font-black"><td className="py-2">Média geral do mês</td><td></td><td>{repStats.avg ? repStats.avg.toFixed(1) : '—'} / 10</td></tr></tbody></table></div>
                <h4 className="font-black text-lg mt-6">Evolução no mês</h4>{repEvolution.length > 1 ? <div className="h-48 mt-2"><ResponsiveContainer width="100%" height="100%"><LineChart data={repEvolution}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" fontSize={12} /><YAxis domain={[0, 10]} fontSize={12} /><Tooltip /><Line type="monotone" dataKey="media" stroke="#6C3FC5" strokeWidth={3} dot={{ fill: '#FFC93C', r: 5 }} /></LineChart></ResponsiveContainer></div> : <p className="text-sm mt-2">Lance pelo menos duas notas em datas diferentes para ver a linha de evolução.</p>}
                <div className="mt-6"><label className="font-black">Observações da professora / mensagem para os pais</label><textarea className="field mt-2 !bg-[#FFFDF7] min-h-[110px]" value={obs} onChange={e => setObs(e.target.value)} placeholder="Escreva aqui um recado carinhoso e específico sobre o progresso do aluno…" /></div>
                <label className="block text-xs font-black mt-3">Nome da professora<input className="field mt-1" value={teacherName} onChange={e => setTeacherName(e.target.value)} placeholder="Flawi" /></label>
                <div className="no-print mt-3"><button onClick={saveNote} className="btn-primary !py-2.5 text-sm flex gap-2 items-center"><Save size={17} /> Salvar observações</button></div>
                <div className="grid grid-cols-2 gap-8 mt-10 pt-6"><div className="border-t-2 border-[#241A38] pt-2 text-sm font-bold">{teacherName}<br /><span className="text-xs">Assinatura da professora</span></div><div className="border-t-2 border-[#241A38] pt-2 text-sm font-bold">Data: ______ / ______ / ______</div></div>
              </article>
            ) : <p className="font-bold">Cadastre um aluno para gerar o relatório.</p>}

            <div className="no-print mt-5 p-5 rounded-3xl border" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}><h3 className="font-black text-lg flex gap-2 items-center"><MessageCircle size={20} style={{ color: 'var(--primary)' }} /> Mensagem para WhatsApp</h3><p className="text-sm font-semibold mb-3" style={{ color: 'var(--muted)' }}>Revise o texto, selecione e copie. Depois é só colar na conversa com o responsável.</p><textarea ref={msgRef} className="field min-h-[180px]" value={whatsappText} onChange={() => {}} /><button onClick={copyWhats} className="btn-yellow mt-3 w-full sm:w-auto">{copied ? 'Copiado! ✓' : 'Copiar mensagem para WhatsApp'}</button></div>
          </section>
        )}

        {tab === 'configuracoes' && (
          <section className="grid lg:grid-cols-5 gap-5">
            <div className="lg:col-span-2 p-5 rounded-3xl border h-fit" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              <h2 className="font-display text-2xl font-black">English Nauta</h2>
              <p className="text-sm font-semibold mt-1" style={{ color: 'var(--muted)' }}>Painel privado da professora.</p>
              <div className="mt-4 space-y-2 text-sm font-bold"><p>Escola: <span className="font-black">English Nauta</span></p><p>Professora: <span className="font-black">Flawi</span></p><p>Acesso: <span className="font-black">Privado · protegido por senha</span></p></div>
              <button onClick={lockApp} className="btn-ghost w-full mt-4 flex justify-center gap-2 items-center"><LogOut size={18} /> Sair / Bloquear agora</button>
              <p className="text-xs font-bold mt-3" style={{ color: 'var(--muted)' }}>Ao sair, o app volta para a tela de senha. Nenhum dado é apagado.</p>
            </div>
            <form onSubmit={handleChangePassword} className="lg:col-span-3 p-5 rounded-3xl border h-fit" style={{ background: 'var(--card)', borderColor: 'var(--line)' }}>
              <h2 className="font-black text-xl flex items-center gap-2"><KeyRound size={20} style={{ color: 'var(--primary)' }} /> Alterar senha</h2>
              <p className="text-sm font-semibold mt-1 mb-4" style={{ color: 'var(--muted)' }}>Digite sua senha atual e escolha uma nova senha.</p>
              <label className="block text-xs font-black mb-1" htmlFor="current-pw">Senha atual</label>
              <div className="relative mb-3"><input id="current-pw" type={showCurrentPw ? 'text' : 'password'} className="field !pr-12" value={currentPw} onChange={e => setCurrentPw(e.target.value)} placeholder="Sua senha atual" autoComplete="current-password" /><button type="button" onClick={() => setShowCurrentPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showCurrentPw ? 'Ocultar senha atual' : 'Mostrar senha atual'}>{showCurrentPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
              <label className="block text-xs font-black mb-1" htmlFor="settings-new">Nova senha</label>
              <div className="relative mb-3"><input id="settings-new" type={showSettingsNewPw ? 'text' : 'password'} className="field !pr-12" value={settingsNewPw} onChange={e => setSettingsNewPw(e.target.value)} placeholder="Nova senha (4 ou mais caracteres)" autoComplete="new-password" /><button type="button" onClick={() => setShowSettingsNewPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showSettingsNewPw ? 'Ocultar nova senha' : 'Mostrar nova senha'}>{showSettingsNewPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
              <label className="block text-xs font-black mb-1" htmlFor="settings-confirm">Confirmar nova senha</label>
              <div className="relative mb-4"><input id="settings-confirm" type={showSettingsConfirmPw ? 'text' : 'password'} className="field !pr-12" value={settingsConfirmPw} onChange={e => setSettingsConfirmPw(e.target.value)} placeholder="Repita a nova senha" autoComplete="new-password" /><button type="button" onClick={() => setShowSettingsConfirmPw(v => !v)} className="absolute right-3 top-1/2 -translate-y-1/2" aria-label={showSettingsConfirmPw ? 'Ocultar confirmação' : 'Mostrar confirmação'}>{showSettingsConfirmPw ? <EyeOff size={19} /> : <Eye size={19} />}</button></div>
              {settingsMsg && <p className="text-sm font-bold mb-3" style={{ color: settingsMsg.includes('sucesso') ? 'var(--good)' : 'var(--bad)' }}>{settingsMsg}</p>}
              <button disabled={settingsBusy} className="btn-primary w-full">{settingsBusy ? 'Alterando…' : 'Alterar senha'}</button>
              <p className="text-xs font-bold mt-3" style={{ color: 'var(--muted)' }}>Esqueceu a senha? Saia do app e use “Esqueci minha senha” na tela de acesso, depois confirme “Sim, sou eu, redefinir”.</p>
            </form>
          </section>
        )}
      </main>
      <footer className="no-print max-w-6xl mx-auto px-6 pb-10 text-center text-xs font-bold" style={{ color: 'var(--muted)' }}>English Nauta · Feito com carinho para a sua sala de inglês. 💜 Professora: Flawi · Os dados são salvos automaticamente.</footer>
        </>
      )}
    </div>
  );
}
